from django.db import models

# Create your models here.
class Member(models.Model):
  firstname = models.CharField(max_length=255)
  lastname = models.CharField(max_length=255)
  phone = models.CharField(max_length=20, null=True, blank=True, default='123-456-7890')
  email = models.EmailField(max_length=255, null=True, blank=True, default='example@example.com')


  def __str__(self):
    return f"{self.firstname} {self.lastname}"