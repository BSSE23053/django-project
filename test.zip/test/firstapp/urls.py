from django.urls import path
from . import views

urlpatterns = [
    path('firstapp/', views.members, name='firstapp'),
     path('user/', views.User, name='user'),
     path('user/details/<int:id>/', views.details, name='details'),
     path('', views.main, name='main'),
     path('testing/', views.testing, name='testing')
]
